CREATE TABLE application (
    id int AUTO_INCREMENT PRIMARY KEY;
    name varchar(120) NOT NULL unique;
    type char "HTTP";
    hostname varchar(120) NOT NULL unique;
    port numeric(10);
    username varchar(40);
    password varchar(40);
    active BOOLEAN NOT NULL;
) engine=MyISAM;

