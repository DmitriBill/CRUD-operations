package WebApplication.CrudOperations.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import WebApplication.CrudOperations.model.WebApp;
import WebApplication.CrudOperations.service.WebAppService;

import javax.validation.Valid;
import java.util.Optional;

@RestController
@RequestMapping("/message")

public class WebAppController {

    @Autowired
    private WebAppService webAppService;


    @PostMapping
    public ResponseEntity<WebApp> saveWebApp(@Valid @RequestBody WebApp webApp){
        return ResponseEntity.status(HttpStatus.CREATED).body(webAppService.saveWebApp(webApp));
    }


    @GetMapping
    public ResponseEntity<Page<WebApp>> getAllWebApp (
            @RequestParam(required = false, defaultValue = "0") Integer page,
            @RequestParam(required = false, defaultValue = "10") Integer size,
            @RequestParam(required = false, defaultValue = "false") Boolean enablePagination
    ){
        return ResponseEntity.ok(webAppService.getAllWebApp(page, size, enablePagination));
    }

    @DeleteMapping(value = "/{id}")
    public ResponseEntity deleteWebApp(@PathVariable ("id") Long id){
        webAppService.deleteWebApp(id);
        return ResponseEntity.ok(!webAppService.existById(id));
    }

    @GetMapping(value = "/{id}")
    public ResponseEntity<Optional<WebApp>> findWebAppById(@PathVariable ("id") Long id){
        return ResponseEntity.status(HttpStatus.OK).body(webAppService.findById(id));
    }

    @PutMapping
    public ResponseEntity<WebApp> editWebApp(@Valid @RequestBody WebApp webApp){
        return ResponseEntity.status(HttpStatus.CREATED).body(webAppService.editWebApp(webApp));
    }
}
