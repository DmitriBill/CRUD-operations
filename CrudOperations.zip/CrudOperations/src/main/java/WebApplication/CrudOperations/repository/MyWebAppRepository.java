package WebApplication.CrudOperations.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import WebApplication.CrudOperations.model.WebApp;

@Repository
public interface MyWebAppRepository extends JpaRepository<WebApp, Long> {

}
