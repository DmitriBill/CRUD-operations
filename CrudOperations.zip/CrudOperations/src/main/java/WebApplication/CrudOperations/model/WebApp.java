package WebApplication.CrudOperations.model;

import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;

@Data
@Entity
@Table(name = "message")
public class WebApp {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @NotBlank
    private String name;
    private String type;
    private String hostname;
    private Integer port;
    private String username;
    private String password;
    private boolean active;
}
