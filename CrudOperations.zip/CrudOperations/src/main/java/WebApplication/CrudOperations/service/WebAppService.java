package WebApplication.CrudOperations.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import WebApplication.CrudOperations.model.WebApp;
import WebApplication.CrudOperations.repository.MyWebAppRepository;

import java.util.Optional;

@Service
public class WebAppService {
    @Autowired
    private MyWebAppRepository myWebAppRepository;


    public WebApp saveWebApp (WebApp webApp){
        if (webApp.getId() == null){
            return myWebAppRepository.save(webApp);
        }
        return null;
    }

    public Page<WebApp> getAllWebApp (Integer page, Integer size, Boolean enablePagination){
        return myWebAppRepository.findAll(enablePagination ? PageRequest.of(page, size): Pageable.unpaged());
    }

    public Optional<WebApp> findById(Long id){
        return myWebAppRepository.findById(id);
    }

    public void deleteWebApp(Long id){
        myWebAppRepository.deleteById(id);
    }

    public WebApp editWebApp (WebApp webApp){
        if (webApp.getId() != null && myWebAppRepository.existsById(webApp.getId())){
            return myWebAppRepository.save(webApp);
        }
        return null;
    }

    public boolean existById(Long id) {
        return myWebAppRepository.existsById(id);
    }
}
